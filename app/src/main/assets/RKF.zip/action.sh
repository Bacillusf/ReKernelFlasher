#!/system/bin/sh
MODDIR=${0%/*}

AVB_DISABLE="$MODDIR/config/avb_disable"
AVB_HIDE="$MODDIR/config/avb_hide"

# Read current state into temp variables (not writing to disk until "save")
tmp_disable=0
tmp_hide=0
[ -f "$AVB_DISABLE" ] && tmp_disable=1
[ -f "$AVB_HIDE" ] && tmp_hide=1

get_status() {
  if [ "$tmp_disable" -eq 1 ]; then echo "YES"; else echo "NO"; fi
}
get_hide_status() {
  if [ "$tmp_hide" -eq 1 ]; then echo "YES"; else echo "NO"; fi
}

wait_key() {
  getevent -qt 1 >/dev/null 2>&1
  while true; do
    event=$(getevent -lqc 1 2>/dev/null | {
      while read -r line; do
        case "$line" in
          *KEY_VOLUMEDOWN*DOWN*) echo "down" && break ;;
          *KEY_VOLUMEUP*DOWN*) echo "up" && break ;;
          *KEY_POWER*DOWN*)
            input keyevent KEY_POWER
            echo "enter" && break ;;
        esac
      done
    })
    [ -n "$event" ] && echo "$event" && return
    usleep 50000
  done
}

SELECTED=0

while true; do
  clear
  echo ""
  echo "╔══════════════════════════════════╗"
  echo "║  欢迎使用 ReKernelFlasher !!!    ║"
  echo "╠══════════════════════════════════╣"
  printf "║  AVB2.0 禁用状态 = %-3s          ║\n" "$(get_status)"
  printf "║  隐藏AVB2.0状态 = %-3s          ║\n" "$(get_hide_status)"
  echo "╚══════════════════════════════════╝"
  echo ""
  echo "  音量键选择, 电源键确认:"
  echo ""

  for i in 0 1 2 3 4; do
    case $i in
      0) opt="禁用AVB2.0" ;;
      1) opt="隐藏AVB2.0状态" ;;
      2) opt="保存应用完整日志信息" ;;
      3) opt="保存并退出" ;;
      4) opt="不保存退出" ;;
    esac
    if [ $i -eq $SELECTED ]; then
      echo "  * $opt"
    else
      echo "    $opt"
    fi
  done

  key=$(wait_key)
  case "$key" in
    up)
      SELECTED=$(( (SELECTED - 1 + 5) % 5 ))
      ;;
    down)
      SELECTED=$(( (SELECTED + 1) % 5 ))
      ;;
    enter)
      case $SELECTED in
        0)
          if [ "$tmp_disable" -eq 1 ]; then
            tmp_disable=0
          else
            tmp_disable=1
          fi
          ;;
        1)
          if [ "$tmp_hide" -eq 1 ]; then
            tmp_hide=0
          else
            tmp_hide=1
          fi
          ;;
        2)
          echo ""
          echo "日志可能包含设备信息，请注意分享范围。"
          logname="/sdcard/$(date +%Y%m%d-%H%M%S)-RKF.log"
          dmesg > "$logname" 2>/dev/null
          logcat -d >> "$logname" 2>/dev/null
          echo "日志已保存到 $logname"
          sleep 2
          ;;
        3)
          mkdir -p "$(dirname "$AVB_DISABLE")"
          if [ "$tmp_disable" -eq 1 ]; then
            touch "$AVB_DISABLE"
          else
            rm -f "$AVB_DISABLE"
          fi
          if [ "$tmp_hide" -eq 1 ]; then
            touch "$AVB_HIDE"
          else
            rm -f "$AVB_HIDE"
          fi
          echo ""
          echo "设置已保存，退出。"
          exit 0
          ;;
        4)
          echo ""
          echo "不保存退出。"
          exit 0
          ;;
      esac
      ;;
  esac
done
