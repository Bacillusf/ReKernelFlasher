#!/system/bin/sh
MODDIR=${0%/*}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 3
done

# AVB disable — controlled by config/avb_disable
if [ -f "$MODDIR/config/avb_disable" ]; then
  $MODDIR/system/bin/avbctl disable-verity --force 2>/dev/null
  $MODDIR/system/bin/avbctl disable-verification --force 2>/dev/null
fi

# AVB hide — controlled by config/avb_hide
if [ -f "$MODDIR/config/avb_hide" ]; then
  resetprop -n ro.boot.vbmeta.device_state locked
  resetprop -n ro.boot.vbmeta.invalidate_on_error yes
  resetprop -n ro.boot.vbmeta.avb_version 2.0
  resetprop -n ro.boot.vbmeta.hash_alg sha256
  resetprop -n ro.boot.vbmeta.size 65536
  resetprop -n ro.boot.veritymode enforcing
fi
