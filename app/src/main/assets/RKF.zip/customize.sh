SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

ui_print "- RKF:Daemon & Ctrl_AVB & Backend v1.0"

# Mark old modules for removal on next reboot (don't rm -rf to avoid breaking active mounts)
for old in autodisableavb hideavb; do
  if [ -d "/data/adb/modules/$old" ]; then
    ui_print "- 检测到旧模块 $old，标记为待移除(重启后生效)"
    touch "/data/adb/modules/$old/remove" 2>/dev/null
    touch "/data/adb/modules/$old/disable" 2>/dev/null
  fi
done

set_perm_recursive $MODPATH/system/bin 0 2000 0755 0755

# Create config directory with defaults enabled
mkdir -p $MODPATH/config
touch $MODPATH/config/avb_disable
touch $MODPATH/config/avb_hide

# AVB disable during install — warn on failure, don't abort
ui_print "- 正在关闭 AVB2.0 校检..."
$MODPATH/system/bin/avbctl disable-verity --force >/dev/null 2>/dev/null \
  && ui_print "  ✓ DM校检已关闭" \
  || ui_print "  ! DM校检关闭失败（可能设备不支持AVB）"
$MODPATH/system/bin/avbctl disable-verification --force >/dev/null 2>/dev/null \
  && ui_print "  ✓ 启动校检已关闭" \
  || ui_print "  ! 启动校检关闭失败（可能设备不支持AVB）"

ui_print "- 安装完成，重启后生效"
